
// script.js (personal_detail.html)
document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("personalDetailsForm");
    form.addEventListener("submit", function(event) {
      event.preventDefault();
  
      // Retrieve input values
      const firstName = document.getElementById("firstName").value;
      const lastName = document.getElementById("lastName").value;
      const email = document.getElementById("email").value;
      const dob = document.getElementById("dob").value;
      const gender = document.querySelector('input[name="gender"]:checked').value;
      const city = document.getElementById("city").value;
      const state = document.getElementById("state").value;
      const permanentAddress = document.getElementById("permanentAddress").value;
      const deliveryAddress = document.getElementById("deliveryAddress").value;
      const pincode = document.getElementById("pincode").value;
      const subscribe = document.querySelector('input[name="subscribe"]:checked').value;
  
      // Send a DELETE request to the API endpoint to clear existing data
      fetch("http://localhost:3000/personaldetails", {
        method: "DELETE"
      })
        .then(() => {
          // Prepare the data object
          const data = {
            firstName,
            lastName,
            email,
            dob,
            gender,
            city,
            state,
            permanentAddress,
            deliveryAddress,
            pincode,
            subscribe
          };
  
          // Send a POST request to the API endpoint to create a new entry
          fetch("http://localhost:3000/personaldetails", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(data),
          })
            .then(() => {
              // Redirect to my_details.html after adding details
              window.location.href = "my_details.html";
            })
            .catch((error) => {
              // Handle the error
              console.error("Error saving data:", error);
            });
        })
        .catch((error) => {
          // Handle the error
          console.error("Error clearing data:", error);
        });
    });
});