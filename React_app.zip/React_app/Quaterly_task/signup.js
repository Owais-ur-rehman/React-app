const signUpForm = document.getElementById('signUpForm');
const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');
const usernameError = document.getElementById('usernameError');
const passwordError = document.getElementById('passwordError');

usernameInput.addEventListener('input', async function() {
  const username = usernameInput.value;
  try {
    const response = await fetch(`http://localhost:3000/credentials?username=${username}`);
    const existingUser = await response.json();
    if (existingUser.length > 0) {
      usernameError.textContent = 'Username already taken!';
      usernameError.style.display = 'block';
    } else {
      usernameError.textContent = '';
      usernameError.style.display = 'none';
    }
  } catch (error) {
    console.error('Error checking username:', error);
  }
});

passwordInput.addEventListener('input', function() {
  const password = passwordInput.value;
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  if (!passwordRegex.test(password)) {
    passwordError.textContent = 'Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, one digit, and one special character.';
    passwordError.style.display = 'block';
  } else {
    passwordError.textContent = '';
    passwordError.style.display = 'none';
  }
});

signUpForm.addEventListener('submit', async function(event) {
  event.preventDefault();
  const username = usernameInput.value;
  const password = passwordInput.value;

  try {
    const response = await fetch(`http://localhost:3000/credentials?username=${username}`);
    const existingUser = await response.json();
    if (existingUser.length > 0) {
      usernameError.textContent = 'Username already taken!';
      usernameError.style.display = 'block';
      return;
    }

    const createUserResponse = await fetch('http://localhost:3000/credentials', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, password })
    });

    if (createUserResponse.ok) {
      window.location.href = 'signin.html';
    } else {
      throw new Error('Failed to sign up');
    }
  } catch (error) {
    console.error('Error signing up:', error);
  }
});