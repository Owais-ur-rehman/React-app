const cartLink = document.querySelector('a[href="cart.html"]');
const navLinks = document.querySelector('.nav-links');

async function getCurrentUser() {
  try {
    const response = await fetch('http://localhost:3000/currentUser');
    const user = await response.json();
    return user.length > 0 ? user[0] : null;
  } catch (error) {
    console.error('Error getting current user:', error);
    return null;
  }
}

async function handleUserData() {
  const currentUser = await getCurrentUser();

  if (currentUser) {
    // Remove the Sign In link
    const signInLink = document.getElementById('signInLink');
    signInLink.parentNode.removeChild(signInLink);
   
    cartLink.href = 'Cart.html';
    cartLink.textContent = 'Cart';

    // Create a new span element to display the username
    const userGreeting = document.createElement('span');
    userGreeting.textContent = `Hi ${currentUser.username}!`;
    userGreeting.style.cursor = 'pointer';

    // Create a new div element for the Sign Out option
    const signOutDiv = document.createElement('div');
    signOutDiv.id = 'small_div';
    signOutDiv.textContent = 'Sign Out';
    signOutDiv.style.border = '1px solid #ccc';
    signOutDiv.style.boxShadow = '0 0 10px rgba(0, 0, 0, 0.5)';
    signOutDiv.style.position = 'fixed';
    signOutDiv.style.left = '86.5%';
    signOutDiv.style.top = '5.5%';
    signOutDiv.style.cursor = 'pointer';
    signOutDiv.style.display = 'none';
    signOutDiv.style.backgroundColor = '#232f3e';
    signOutDiv.style.padding = '5px 10px';
    signOutDiv.style.zIndex = '9998';

    // Append the username and Sign Out div to the nav links
    navLinks.appendChild(userGreeting);
    navLinks.appendChild(signOutDiv);

    // Show/hide the Sign Out div on click
    let isSignOutVisible = false;
    userGreeting.addEventListener('click', () => {
      isSignOutVisible = !isSignOutVisible;
      signOutDiv.style.display = isSignOutVisible ? 'inline' : 'none';
    });

    // Add event listener to Sign Out div
    signOutDiv.addEventListener('click', async () => {
      try {
        // Fetch the current user data
        const response = await fetch('http://localhost:3000/currentUser');
        const userData = await response.json();
    
        if (userData.length > 0) {
          const userId = userData[0].id;
    
          // Make the DELETE request with the correct user ID
          const deleteResponse = await fetch(`http://localhost:3000/currentUser/${userId}`, {
            method: 'DELETE'
          });
    
          if (deleteResponse.ok) {
          const signInLinkNew = document.createElement('a');
          signInLinkNew.href = 'signin.html';
          signInLinkNew.textContent = 'Sign In';
          signInLinkNew.id = 'signInLink';
          navLinks.appendChild(signInLinkNew);
          

          // Remove the user greeting and Sign Out div
          userGreeting.remove();
          signOutDiv.remove();
          alert("You have signed out!");
          } else {
            throw new Error('Failed to sign out');
          }
        } else {
          console.log('No user data found');
        }
      } catch (error) {
        console.error('Error signing out:', error);
      }
    });
  } else {
    cartLink.href = '';
    cartLink.textContent = '';
  }
}

handleUserData();