document.addEventListener("DOMContentLoaded", function() {
    const menuIcon = document.getElementById('menuIcon');
    const sidebar = document.getElementById('sidebar');
    
    async function getCurrentUser() {
      try {
        const response = await fetch('http://localhost:3000/currentUser');
    
        if (!response.ok) {
          const errorMessage = response.status
            ? `HTTP error ${response.status}`
            : 'An unknown error occurred';
          throw new Error(errorMessage);
        }
    
        const user = await response.json();
        return user.length > 0 ? user[0] : null;
      } catch (error) {
        console.error('Error getting current user:', error);
        return null;
      }
    }
    menuIcon.addEventListener('click', function() {
        // Toggle sidebar visibility
        if (sidebar.style.left === '-250px') {
          sidebar.style.left = '0';
        } else {
          sidebar.style.left = '-250px';
        }
    });
  
    const productGrid = document.getElementById('productGrid');
  
    productGrid.addEventListener('mouseover', function(event) {
        const target = event.target;
        if (target.tagName === 'IMG' && target.parentElement.classList.contains('product-item')) {
            target.classList.add('shadow');
        }
    });

    productGrid.addEventListener('mouseout', function(event) {
        const target = event.target;
        if (target.tagName === 'IMG' && target.parentElement.classList.contains('product-item')) {
            target.classList.remove('shadow');
        }
    });

    productGrid.addEventListener('click', function(event) {
        const target = event.target;
        if (target.tagName === 'IMG' && target.parentElement.classList.contains('product-item')) {
            const productItem = target.parentElement;
            handleAddToCart(productItem);
        }
    });

    // Search Functionality
  async function fetchProductsData() {
  try {
        const response = await fetch('http://localhost:3000/products');
        const products = await response.json();
        return products;
      } catch (error) {
        console.error('Error fetching products data:', error);
      }
  }

async function renderInitialProducts() {
  const products = await fetchProductsData();
  renderProducts(products);
}

renderInitialProducts();

// Search Functionality
const searchInput = document.getElementById('searchInput');
const searchButton = document.getElementById('searchButton');
const featuredProductsHeading = document.querySelector('.featured-products h2');

searchButton.addEventListener('click', async function() {
  const searchTerm = searchInput.value.toLowerCase();
  const products = await fetchProductsData();
  const filteredProducts = products.filter(function(product) {
    return product.name.toLowerCase().includes(searchTerm);
  });
  renderProducts(filteredProducts);
  if (searchTerm.trim() !== '') {
    featuredProductsHeading.textContent = `You searched for "${searchTerm}"`;
  } else {
    featuredProductsHeading.textContent = 'Featured Products';
  }
});

function renderProducts(productList) {
  const productGridElement = document.getElementById('productGrid');
  productGridElement.innerHTML = '';
  productList.forEach(function(product) {
    const productItem = document.createElement('div');
    productItem.classList.add('product-item');
    const productImage = document.createElement('img');
    productImage.src = product.image;
    productImage.alt = product.name;
    const productName = document.createElement('p');
    productName.textContent = product.name;
    const productPrice = document.createElement('p');
    productPrice.textContent = `$${product.price}`;
    productItem.appendChild(productImage);
    productItem.appendChild(productName);
    productItem.appendChild(productPrice);
    productGridElement.appendChild(productItem);
  });
}
  
    function handleAddToCart(productItem) {
      const currentUser = getCurrentUser();
      if (!currentUser) {
        showSignInPopup();
        return;
      }
    
      const productName = productItem.querySelector('p:first-of-type').textContent;
      const productPrice = productItem.querySelector('p:last-of-type').textContent.replace(/\D/g, '');
    
      const cartItemDiv = productItem.querySelector('.cart-item');
    
      if (cartItemDiv) {
        toggleCartItem(cartItemDiv);
      } else {
        const priceElement = document.createElement('p'); // Create the priceElement
        const newCartItemDiv = createCartItem(productItem, productName, productPrice, priceElement);
        productItem.appendChild(newCartItemDiv);
      }
    }

    function showSignInPopup(event) {
  const popup = document.createElement('div');
  popup.style.position = 'fixed';
  popup.style.top = '50%';
  popup.style.left = '50%';
  popup.style.transform = 'translate(-50%, -50%)';
  popup.style.backgroundColor = '#fff';
  popup.style.padding = '20px';
  popup.style.border = '1px solid #ccc';
  popup.style.boxShadow = '0 0 10px rgba(0, 0, 0, 0.5)';
  popup.style.zIndex = '9999';

  const message = document.createElement('p');
  message.textContent = "Oops! Seems you are not signed in. Please sign in here. You won't be able to access cart without signing in";

  const signInButton = document.createElement('button');
  signInButton.textContent = 'Sign In';
  signInButton.style.marginTop = '10px';
  signInButton.addEventListener('click', async function() {
    const currentUser = await getCurrentUser();
    if (currentUser) {
      window.location.href = 'cart.html';
    } else {
      window.location.href = 'signin.html';
    }
    popup.remove();
  });

  const continButton = document.createElement('button');
  continButton.textContent = 'Continue Without Sign in';
  continButton.style.marginTop = '10px';
  continButton.style.marginLeft = '30px';
  continButton.addEventListener('click', function() {
    window.location.href = 'index.html';
    popup.remove();
  });

  popup.appendChild(message);
  popup.appendChild(signInButton);
  popup.appendChild(continButton);
  document.body.appendChild(popup);

  if (event) {
    event.preventDefault(); // Prevent the link from navigating
  }
}
 function createCartItem(productItem, productName, productPrice) {
      const cartItemDiv = document.createElement('div');
      cartItemDiv.style.display = 'none';
      cartItemDiv.style.justifyContent = 'space-between';
      cartItemDiv.style.alignItems = 'center';
      cartItemDiv.style.padding = '10px';
      cartItemDiv.style.border = '1px solid #ccc';
      cartItemDiv.style.marginTop = '10px';
      cartItemDiv.classList.add('cart-item');
    
      const productNameElement = document.createElement('p');
      productNameElement.textContent = productName;
    
      const countElement = document.createElement('span');
      let count = 1;
      countElement.textContent = count;
    
      const incrementButton = document.createElement('button');
      incrementButton.textContent = '+';
      incrementButton.addEventListener('click', function() {
        count++;
        countElement.textContent = count;
        updateCartItemPrice(cartItemDiv, productPrice, count, priceElement);
      });
    
      const decrementButton = document.createElement('button');
      decrementButton.textContent = '-';
      decrementButton.addEventListener('click', function() {
        if (count > 1) {
          count--;
          countElement.textContent = count;
          updateCartItemPrice(cartItemDiv, productPrice, count, priceElement);
        }
      });
    
      const addToCartButton = document.createElement('button');
      addToCartButton.textContent = 'Add to Cart';
      addToCartButton.addEventListener('click', async function() {
        const currentUser = await getCurrentUser();
        if (currentUser) {
          storeCartItemInAPI(productName, productPrice, count, currentUser.id);
        } else {
          showSignInPopup();
        }
      });
    
      const goToCartButton = document.createElement('button');
      goToCartButton.textContent = 'Go to Cart';
      goToCartButton.id = 'cart_button';
      goToCartButton.addEventListener('click', async function() {
        const currentUser = await getCurrentUser();
        if (currentUser) {
          window.location.href = 'cart.html';
        } else {
          showSignInPopup();
        }
      });
    
      const priceElement = document.createElement('p');
      updateCartItemPrice(cartItemDiv, productPrice, count, priceElement);
    
      cartItemDiv.appendChild(productNameElement);
      cartItemDiv.appendChild(decrementButton);
      cartItemDiv.appendChild(countElement);
      cartItemDiv.appendChild(incrementButton);
      cartItemDiv.appendChild(priceElement);
      cartItemDiv.appendChild(addToCartButton);
      cartItemDiv.appendChild(goToCartButton);
    
      return cartItemDiv; // Return the cartItemDiv
    }
  
    function toggleCartItem(cartItemDiv) {
      if (cartItemDiv.style.display === 'none') {
        cartItemDiv.style.display = 'flex';
      } else {
        cartItemDiv.style.display = 'none';
      }
    }
  
    function updateCartItemPrice(cartItemDiv, productPrice, count) {
      const totalPrice = productPrice * count;
      const priceElement = cartItemDiv.querySelector('p:last-of-type');
      if (priceElement) { // Check if priceElement is not null
        priceElement.textContent = `$${totalPrice}`;
      }
    }
    function storeCartItemInAPI(productName, productPrice, count, userId) {
      const cartItem = {
        userId,
        productName,
        productPrice,
        count
      };
    
      fetch('http://localhost:3000/cart_item', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(cartItem)
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Failed to store cart item');
        }
      })
      .catch(error => {
        console.error('Error storing cart item:', error);
      });
    }
});
