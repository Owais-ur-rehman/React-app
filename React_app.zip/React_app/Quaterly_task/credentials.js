// credentials.js
const credentials = JSON.parse(localStorage.getItem('credentials')) || [];
