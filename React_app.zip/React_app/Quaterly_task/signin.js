const signInForm = document.getElementById('signInForm');
const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');
const usernameError = document.getElementById('usernameError');
const passwordError = document.getElementById('passwordError');
const signInMessage = document.getElementById('signInMessage');

usernameInput.addEventListener('input', async function() {
  const username = usernameInput.value;
  try {
    const response = await fetch(`http://localhost:3000/credentials?username=${username}`);
    const existingUser = await response.json();
    if (existingUser.length>0) {
      usernameError.textContent = '';
  } else {
    usernameError.textContent = 'Invalid username!';
    usernameError.style.display = 'block';
  }
  } catch (error) {
    console.error('Error checking username:', error);
  }
});

passwordInput.addEventListener('input', function() {
  const password = passwordInput.value;
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  if (!passwordRegex.test(password)) {
    passwordError.textContent = 'Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, one digit, and one special character.';
    passwordError.style.display = 'block';
  } else {
    passwordError.textContent = '';
    passwordError.style.display = 'none';
  }
});

signInForm.addEventListener('submit', async function(event) {
  event.preventDefault();
  const username = usernameInput.value;
  const password = passwordInput.value;

  try {
    const response = await fetch(`http://localhost:3000/credentials?username=${username}&password=${password}`);
    const user = await response.json();
    if (user.length > 0) {
      signInMessage.textContent = 'Sign-in successful!';
      signInMessage.style.color = 'green';
      // Store the user data in the API
      await storeUserData(user[0]);
        window.location.href = 'index.html';
    } else {
      signInMessage.textContent = 'Invalid username or password!';
      signInMessage.style.color = 'red';
    }
  } catch (error) {
    console.error('Error signing in:', error);
  }
});

async function storeUserData(user) {
  try {
    const response = await fetch('http://localhost:3000/currentUser', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(user)
    });

    if (!response.ok) {
      throw new Error('Failed to store user data');
    }
  } catch (error) {
    console.error('Error storing user data:', error);
  }
}