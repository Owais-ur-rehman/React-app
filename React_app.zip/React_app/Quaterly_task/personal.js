// script.js (personal_detail.html)
document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("personalDetailsForm");

    form.addEventListener("submit", function(event) {
        event.preventDefault(); // Prevent form submission

        // Retrieve input values
        const firstName = document.getElementById("firstName").value;
        const lastName = document.getElementById("lastName").value;
        const email = document.getElementById("email").value;
        const dob = document.getElementById("dob").value;
        const gender = document.querySelector('input[name="gender"]:checked').value;
        const city = document.getElementById("city").value;
        const state = document.getElementById("state").value;
        const permanentAddress = document.getElementById("permanentAddress").value;
        const deliveryAddress = document.getElementById("deliveryAddress").value;
        const pincode = document.getElementById("pincode").value;
        const subscribe = document.querySelector('input[name="subscribe"]:checked').value;

        // Store input values in localStorage
        localStorage.setItem("firstName", firstName);
        localStorage.setItem("lastName", lastName);
        localStorage.setItem("email", email);
        localStorage.setItem("dob", dob);
        localStorage.setItem("gender", gender);
        localStorage.setItem("city", city);
        localStorage.setItem("state", state);
        localStorage.setItem("permanentAddress", permanentAddress);
        localStorage.setItem("deliveryAddress", deliveryAddress);
        localStorage.setItem("pincode", pincode);
        localStorage.setItem("subscribe", subscribe);

        // Redirect to my_details.html
        window.location.href = "my_details.html";
    });
});
