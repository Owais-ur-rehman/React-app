// script.js (my_details.html)
document.addEventListener("DOMContentLoaded", function() {
    const myDetailsContainer = document.getElementById("myDetails");

    // Fetch personal details from the API endpoint
    fetch("http://localhost:3000/personaldetails")
      .then((response) => response.json())
      .then((data) => {
        // Log the fetched data
        console.log("Fetched data:", data);

        // Extract individual data fields
        const firstName = data.firstName;
        const lastName = data.lastName;
        const email = data.email;
        const dob = data.dob;
        const gender = data.gender;
        const city = data.city;
        const state = data.state;
        const permanentAddress = data.permanentAddress;
        const deliveryAddress = data.deliveryAddress;
        const pincode = data.pincode;
        const subscribe = data.subscribe;

        // Construct HTML for displaying details
        const detailsHTML = `
          <p><strong>First Name:</strong> ${firstName}</p>
          <p><strong>Last Name:</strong> ${lastName}</p>
          <p><strong>Email:</strong> ${email}</p>
          <p><strong>Date of Birth:</strong> ${dob}</p>
          <p><strong>Gender:</strong> ${gender}</p>
          <p><strong>City:</strong> ${city}</p>
          <p><strong>State:</strong> ${state}</p>
          <p><strong>Permanent Address:</strong> ${permanentAddress}</p>
          <p><strong>Delivery Address:</strong> ${deliveryAddress}</p>
          <p><strong>Pin Code:</strong> ${pincode}</p>
          <p><strong>Subscribe to Delivery Updates:</strong> ${subscribe}</p>
        `;
  
        // Display details in my_details.html
        myDetailsContainer.innerHTML = detailsHTML;
      })
      .catch((error) => {
        // Handle the error
        console.error("Error fetching data:", error);
      });

    // Update button functionality
    const updateButton = document.getElementById("update");
    if (updateButton) {
      updateButton.addEventListener("click", function() {
        window.location.href = "personal_details.html";
      });
    }
});