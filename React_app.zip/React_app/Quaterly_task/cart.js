document.addEventListener("DOMContentLoaded", async function() {
  const cartItemsContainer = document.getElementById('cartItems');
  const totalPriceElement = document.getElementById('totalPrice');

  try {
    const response = await fetch('http://localhost:3000/cart_item');
    const cartItems = await response.json();
    let totalPrice = 0;

    cartItems.forEach(function(item) {
      const cartItemDiv = document.createElement('div');
      cartItemDiv.style.display = 'flex';
      cartItemDiv.style.justifyContent = 'space-between';
      cartItemDiv.style.alignItems = 'center';
      cartItemDiv.style.padding = '10px';
      cartItemDiv.style.border = '1px solid #ccc';
      cartItemDiv.style.marginBottom = '10px';

      const productNameElement = document.createElement('p');
      productNameElement.style.margin = '0';
      productNameElement.textContent = item.productName; // Use productName instead of name

      const countElement = document.createElement('span');
      countElement.textContent = `Count: ${item.count}`;

      const priceElement = document.createElement('p');
      priceElement.style.margin = '0';
      const itemTotalPrice = item.productPrice * item.count; // Use productPrice instead of price
      priceElement.textContent = `Price: $${itemTotalPrice}`;
      totalPrice += itemTotalPrice;

      const removeButton = document.createElement('button');
      removeButton.textContent = 'Remove Item';
      removeButton.addEventListener('click', async function() {
        try {
          const deleteResponse = await fetch(`http://localhost:3000/cart_item/${item.id}`, {
            method: 'DELETE'
          });
          if (deleteResponse.ok) {
            // Remove the item from the cart and update the total price
            totalPrice -= itemTotalPrice;
            totalPriceElement.textContent = `Total Price: $${totalPrice}`;
            cartItemDiv.remove();
          } else {
            throw new Error('Failed to remove cart item');
          }
        } catch (error) {
          console.error('Error removing cart item:', error);
        }
      });

      cartItemDiv.appendChild(productNameElement);
      cartItemDiv.appendChild(countElement);
      cartItemDiv.appendChild(priceElement);
      cartItemDiv.appendChild(removeButton);
      cartItemsContainer.appendChild(cartItemDiv);
    });

    totalPriceElement.textContent = `Total Price: $${totalPrice}`;
  } catch (error) {
    console.error('Error fetching cart items:', error);
  }
});