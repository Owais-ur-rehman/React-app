import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FiSun, FiMoon } from 'react-icons/fi';
import './Navbar.css';

function Navbar({ user, onLogout }) {
  const [theme, setTheme] = useState('light');
  const [showDropdown, setShowDropdown] = useState(false);
  const [showLogoutConfirmation, setShowLogoutConfirmation] = useState(false);
  const [profilePicture, setProfilePicture] = useState('profile.jpg');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProfilePicture = async () => {
      try {
        const response = await fetch(`http://localhost:3004/users/${user.id}`);
        const userData = await response.json();
        setProfilePicture(userData.profilePicture);
      } catch (error) {
        console.error('Error fetching profile picture:', error);
      }
    };

    if (user) {
      fetchProfilePicture();
    }
  }, []);

  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
    document.body.classList.toggle('dark');
  };

  const toggleDropdown = () => {
    setShowDropdown(!showDropdown);
  };

  const handleLogout = () => {
    if (showLogoutConfirmation) {
      onLogout();
      navigate('/');
      setShowLogoutConfirmation(false);
    } else {
      setShowLogoutConfirmation(true);
    }
  };

  return (
    <nav className={`navbar ${theme === 'dark' ? 'dark' : ''}`}>
      <div className="navbar__logo">
        <img src="logo.png" alt="Broadgram" />
        <span>Broadgram</span>
      </div>
      <div className="navbar__right">
        {user ? (
          <div className="navbar__profile" onClick={toggleDropdown}>
            <img src="profile.jpg" alt="Profile" />
            <span className="navbar__username">{user.username}</span>
            {showDropdown && (
              <div className="navbar__dropdown">
                <Link to="/edit-details">Preferences</Link>
                <a onClick={handleLogout}>Logout</a>
              </div>
            )}
          </div>
        ) : (
          <Link className='link' to="/login">Login</Link>
        )}
        <a className="navbar__theme-toggle" onClick={toggleTheme}>
          {theme === 'light' ? <FiMoon /> : <FiSun />}
        </a>
      </div>
      {showLogoutConfirmation && (
        <div className={`logout-confirmation ${theme === 'dark' ? 'dark' : ''}`}>
          <div className="logout-confirmation__content">
            <p>Are you sure you want to logout?</p>
            <a id="button" onClick={handleLogout}>
              Yes
            </a>
            <a
              id="button"
              className="no"
              onClick={() => setShowLogoutConfirmation(false)}
            >
              No
            </a>
          </div>
        </div>
      )}
    </nav>
  );
}

export default Navbar;