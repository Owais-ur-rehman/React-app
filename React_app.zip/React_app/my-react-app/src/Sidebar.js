import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FiGrid, FiEdit, FiPlus, FiHelpCircle } from 'react-icons/fi';
import './Sidebar.css';

function Sidebar() {
  const [theme, setTheme] = useState('light');

  return (
    <div className={`sidebar ${theme === 'dark' ? 'dark' : ''}`}>
      <ul className="sidebar__links">
        <li>
          <Link to="/dashboard">
            <FiGrid /> <p>Dashboard</p>
          </Link>
        </li>
        <li>
          <Link to="/create-post">
            <FiPlus /> <p>Create Post</p>
          </Link>
        </li>
        <li>
          <Link to="/edit-details">
            <FiEdit /> <p>Edit Details</p>
          </Link>
        </li>
        <li>
          <Link to="/support">
            <FiHelpCircle /> <p>Support</p>
          </Link>
        </li>
      </ul>
    </div>
  );
}

export default Sidebar;
