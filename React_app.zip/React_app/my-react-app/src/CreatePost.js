import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './CreatePost.css';

const CreatePost = () => {
  const [postData, setPostData] = useState({
    text: '',
    username: '',
    image: null
  });
  const navigate = useNavigate();

  const handleChange = (e) => {
    if (e.target.name === 'image') {
      setPostData({ ...postData, [e.target.name]: e.target.files[0] });
    } else {
      setPostData({ ...postData, [e.target.name]: e.target.value });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!postData.username) {
      alert('Please enter a username');
      return;
    }

    const formData = new FormData();
    formData.append('text', postData.text);
    formData.append('username', postData.username);
    if (postData.image) {
      formData.append('image', postData.image.name);
    }

    try {
      await axios.post('http://localhost:3004/posts', Object.fromEntries(formData));
      // Reset form or show success message
      navigate('/dashboard'); // Navigate to the dashboard after successful post creation
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className="create-post">
      <h2>Create Post</h2>
      <form onSubmit={handleSubmit} className="create-post__form">
        <input
          type="text"
          name="username"
          placeholder="Enter your username"
          value={postData.username}
          onChange={handleChange}
          required
          className="create-post__username"
        />
        <textarea
          name="text"
          placeholder="What's on your mind?"
          value={postData.text}
          onChange={handleChange}
          className="create-post__text"
        />
        <div className="create-post__image">
          <input
            className="file_button"
            type="file"
            name="image"
            accept="image/*"
            
            onChange={handleChange}
          />
        </div>
        <button type="submit" className="create-post__button">
          Post
        </button>
      </form>
    </div>
  );
};

export default CreatePost;