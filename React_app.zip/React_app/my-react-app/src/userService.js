const apiUrl = 'http://localhost:3004/users';

export const login = async (username, password) => {
    try {
      const response = await fetch(`${apiUrl}?username=${username}`);
      const users = await response.json();
      const user = users.find((u) => u.username === username);
      if (!user) {
        throw new Error('Username not found');
      }
      if (user.password !== password) {
        throw new Error('Incorrect password');
      }
      return user;
    } catch (err) {
      throw new Error('An error occurred while logging in');
    }
  };

export const register = async (userData) => {
  try {
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(userData),
    });
    if (response.ok) {
      const user = await response.json();
      return user;
    } else {
      throw new Error('An error occurred while registering');
    }
  } catch (err) {
    throw err;
  }
};

export const getUserById = async (id) => {
  try {
    const response = await fetch(`${apiUrl}/${id}`);
    const user = await response.json();
    return user;
  } catch (err) {
    throw new Error('An error occurred while fetching user data');
  }
};

export const updateUser = async (id, userData) => {
  try {
    const response = await fetch(`${apiUrl}/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(userData),
    });
    if (response.ok) {
      const updatedUser = await response.json();
      return updatedUser;
    } else {
      throw new Error('An error occurred while updating user data');
    }
  } catch
  (err) {
    throw err;
  }
};