import React from 'react';
import { Navigate } from 'react-router-dom';
import LoginModal from './LoginModal';

function PrivateRoute({ isAuthenticated, children }) {
  if (!isAuthenticated) {
    return <LoginModal />;
  }

  return children;
}

export default PrivateRoute;





