import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { login } from './userService';
import './Login.css';

const Login = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const user = await login(username, password);
      if (user) {
        onLogin(user);
        navigate('/dashboard');
      } else {
        setError('Invalid username or password');
      }
    } catch (err) {
      setError('Invalid username or password');
    }
  };

  const handleContinueWithoutLogin = () => {
    navigate('/dashboard');
  };
  const handlenewtobroadgram = ()=> {
    navigate('/Register');
  }

  return (
    <div className='login'>
      <h2>Log in</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="username">Username</label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <button type="submit">Log in</button>
        <button type="button" onClick={handleContinueWithoutLogin}>
          Continue without login
        </button>
        <button type="button" onClick={handlenewtobroadgram}>
          New to Broadgram? Register here
        </button>
      </form>
    </div>
  );
};

export default Login;