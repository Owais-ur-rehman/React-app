import React from 'react';
import { Link } from 'react-router-dom';
import './LoginModal.css';

function LoginModal() {
  return (
    <div className="login-modal">
      <div className="login-modal__content">
        <h2>Please Log In</h2>
        <p>You need to be logged in to access this feature.</p>
        <Link to="/login" className="login-modal__button">
          Log In
        </Link>
        <Link to="/dashboard" className="login-modal__button">
          Cancel
        </Link>
      </div>
    </div>
  );
}

export default LoginModal;