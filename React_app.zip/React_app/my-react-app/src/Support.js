import React from 'react';
import './Support.css';

const Support = () => {
  return (
    <div className="support-container">
      <h1>Support</h1>
      <p>
        Welcome to the Broadgram Support page! Here you'll find helpful resources and information to assist you with any questions or issues you may have while using our platform.
      </p>

      <h2>Frequently Asked Questions</h2>
      <table className="faq-table">
        <thead>
          <tr>
            <th>Question</th>
            <th>Answer</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>How do I create a new post?</td>
            <td>To create a new post, click on the "Create Post" button in the sidebar. You can then enter your post text, upload an image (optional), and submit the post.</td>
          </tr>
          <tr>
            <td>How do I like or comment on a post?</td>
            <td>On the Dashboard, you'll see a "Like" button and a "Comment" button below each post. Click the "Like" button to like the post, and click the "Comment" button to open the comment box and leave a comment.</td>
          </tr>
          <tr>
            <td>How do I update my profile details?</td>
            <td>Click on your profile picture in the top-right corner, then select "Preferences" from the dropdown menu. On the Edit Details page, you can update your personal information, profile picture, and other settings.</td>
          </tr>
        </tbody>
      </table>

      <h2>Contact Us</h2>
      <p>
        If you have any further questions or need assistance, please don't hesitate to reach out to our support team. You can contact us via email at <a href="mailto:support@broadgram.com">support@broadgram.com</a> or through our online chat support (available during business hours).
      </p>
    </div>
  );
};

export default Support;