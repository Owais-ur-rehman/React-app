import React, { useState, useEffect } from 'react';
import './EditDetails.css';

const EditDetails = ({ userId }) => {
  const [userDetails, setUserDetails] = useState({
    email: '',
    phoneNumber: '',
    firstName: '',
    lastName: '',
    dateOfBirth: '',
    gender: '',
    profilePicture: '',
  });
  const [successMessage, setSuccessMessage] = useState('');
  const [file, setFile] = useState(null);
  const [previewImage, setPreviewImage] = useState(null);

  useEffect(() => {
    // Fetch user details from the server API
    const fetchUserDetails = async () => {
      try {
        if (!userId) {
          console.error('User ID is not provided');
          return;
        }

        const response = await fetch(`http://localhost:3004/users/${userId}`);
        if (!response.ok) {
          throw new Error('Failed to fetch user details');
        }
        const data = await response.json();
        setUserDetails(data);
      } catch (error) {
        console.error('Error fetching user details:', error);
      }
    };
    fetchUserDetails();
  }, []);

  const handleInputChange = (e) => {
    setUserDetails({ ...userDetails, [e.target.name]: e.target.value });
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setFile(file);
    setPreviewImage(URL.createObjectURL(file));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (!userId) {
        console.error('User ID is not provided');
        return;
      }

      const data = {
        ...userDetails,
        profilePicture: file ? file.name : userDetails.profilePicture,
      };

      await fetch(`http://localhost:3004/users/${userId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      // Display success message
      setSuccessMessage('Details updated successfully');
    } catch (error) {
      console.error('Error updating details:', error);
    }
  };

  return (
    <div className="edit-details">
      <h2>Edit Details</h2>
      <div className="profile-preview">
        {previewImage ? (
          <img
            src={previewImage}
            alt="Profile Preview"
            className="profile-picture"
          />
        ) : (
          <img
            src={userDetails.profilePicture}
            alt="Profile"
            className="profile-picture"
          />
        )}
        <label htmlFor="file-input" className="file-input-label">
          Choose Profile Picture
        </label>
        <input
          id="file-input"
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          className="file-input"
        />
      </div>
      {successMessage && <p className="success-message">{successMessage}</p>}
      <form onSubmit={handleSubmit} className="edit-details-form">
        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            name="email"
            id="email"
            value={userDetails.email}
            onChange={handleInputChange}
            placeholder="Email"
            className="form-input"
          />
        </div>
        <div className="form-group">
          <label htmlFor="phoneNumber">Phone Number</label>
          <input
            type="tel"
            name="phoneNumber"
            id="phoneNumber"
            value={userDetails.phoneNumber}
            onChange={handleInputChange}
            placeholder="Phone Number"
            className="form-input"
          />
        </div>
        <div className="form-group">
          <label htmlFor="firstName">First Name</label>
          <input
            type="text"
            name="firstName"
            id="firstName"
            value={userDetails.firstName}
            onChange={handleInputChange}
            placeholder="First Name"
            className="form-input"
          />
        </div>
        <div className="form-group">
          <label htmlFor="lastName">Last Name</label>
          <input
            type="text"
            name="lastName"
            id="lastName"
            value={userDetails.lastName}
            onChange={handleInputChange}
            placeholder="Last Name"
            className="form-input"
          />
        </div>
        <div className="form-group">
          <label htmlFor="dateOfBirth">Date of Birth</label>
          <input
            type="date"
            name="dateOfBirth"
            id="dateOfBirth"
            value={userDetails.dateOfBirth}
            onChange={handleInputChange}
            placeholder="Date of Birth"
            className="form-input"
          />
        </div>
        <div className="form-group">
          <label htmlFor="gender">Gender</label>
          <select
            name="gender"
            id="gender"
            value={userDetails.gender}
            onChange={handleInputChange}
            className="form-input"
          >
            <option value="">Select Gender</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
          </select>
        </div>
        <button type="submit" className="update-button">
          Update Details
        </button>
      </form>
    </div>
  );
};

export default EditDetails;