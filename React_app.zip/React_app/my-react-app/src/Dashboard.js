import React, { useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faThumbsUp, faComment } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';
import './Dashboard.css';

const Dashboard = () => {
  const [posts, setPosts] = useState([]);
  const [showCommentBox, setShowCommentBox] = useState(null);
  const [newComment, setNewComment] = useState('');
  const [comments, setComments] = useState([]);
  const [theme, setTheme] = useState('light');

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const response = await fetch('http://localhost:3004/posts');
        const data = await response.json();
        setPosts(data);
      } catch (error) {
        console.error(error);
      }
    };
    fetchPosts();
  }, []);

  useEffect(() => {
    const fetchComments = async () => {
      try {
        const response = await fetch('http://localhost:3004/comments');
        const data = await response.json();
        setComments(data);
      } catch (error) {
        console.error(error);
      }
    };
    fetchComments();
  }, [posts]);

  const handleLike = async (postId, event) => {
    event.preventDefault(); // Prevent the default button behavior
    try {
      const response = await axios.patch(`http://localhost:3004/posts/${postId}`, {
        likes: posts.find((post) => post.id === postId).likes + 1
      });
      setPosts(posts.map((post) => (post.id === postId ? response.data : post)));
    } catch (error) {
      console.error(error);
    }
  };

  const handleComment = (postId, event) => {
    if (showCommentBox === postId) {
      setShowCommentBox(null);
    } else {
      setShowCommentBox(postId);
    }
  };

  const handleCommentSubmit = async (postId, event) => {
    try {
      const response = await axios.post(`http://localhost:3004/comments`, {
        postId,
        comment: newComment
      });
      setComments([...comments, response.data]);
      setNewComment('');
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className="dashboard">
      <h1>Dashboard</h1>
      <div className={`posts ${theme === 'dark' ? 'dark' : ''}`}>
        {posts.map((post) => (
          <div key={post.id} className={`post ${theme === 'dark' ? 'dark' : ''}`}>
            {post.username && (
              <div className={`post__header ${theme === 'dark' ? 'dark' : ''}`}>
                <span className="post__username">{post.username}</span>
              </div>
            )}
            <div className="post__content">
              {post.image && <img src={`http://localhost:3004/${post.image}`} alt="Post" className="post__image" />}
              <div className="post__text-container">
                <p className="post__text">{post.text}</p>
              </div>
            </div>
            <div className="post__actions">
              <button type="button" className="post__like" onClick={(event) => handleLike(post.id, event)}>
                <FontAwesomeIcon icon={faThumbsUp} /> {post.likes || 0}
              </button>
              <button type="button" className="post__comment" onClick={() => handleComment(post.id)}>
                <FontAwesomeIcon icon={faComment} /> Comment
              </button>
            </div>
            {showCommentBox === post.id && (
              <div className="comment-box">
                <form onSubmit={(event) => handleCommentSubmit(post.id, event)} className="comment-form">
                  <textarea
                    value={newComment}
                    onChange={(event) => setNewComment(event.target.value)}
                    placeholder="Write a comment..."
                    className="comment-input"
                  />
                  <button type="submit" className="comment-submit">
                    Post Comment
                  </button>
                </form>
                <div className="comments">
                  {comments
                    .filter((comment) => comment.postId === post.id)
                    .map((comment) => (
                      <div key={comment.id} className="comment">
                        <p>{comment.comment}</p>
                      </div>
                    ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;