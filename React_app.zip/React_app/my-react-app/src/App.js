import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './Navbar';
import Sidebar from './Sidebar';
import Dashboard from './Dashboard';
import CreatePost from './CreatePost';
import EditDetails from './EditDetails';
import Support from './Support';
import Footer from './Footer';
import Login from './Login';
import Register from './Register';
import PrivateRoute from './PrivateRoute';
import './App.css';

function App() {
  const [theme, setTheme] = useState('light');
  const [user, setUser] = useState(null);

  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
    document.body.classList.toggle('dark');
  };

  const handleLogin = (userData) => {
    setUser(userData);
  };

  const handleLogout = () => {
    setUser(null);
  };

  return (
    <Router>
      <div className={`app ${theme}`}>
        <Navbar toggleTheme={toggleTheme} user={user} onLogout={handleLogout} />
        <div className="app__container">
          <Sidebar />
          <Routes>
            <Route path="/login" element={<Login onLogin={handleLogin} />} />
            <Route path="/register" element={<Register />} />
            <Route path="/dashboard" element={<Dashboard user={user} />} />
            <Route
              path="/create-post"
              element={
                <PrivateRoute isAuthenticated={!!user}>
                  <CreatePost user={user} />
                </PrivateRoute>
              }
            />
            <Route
              path="/edit-details"
              element={
                <PrivateRoute isAuthenticated={!!user}>
                  <EditDetails user={user} onUpdate={handleLogin} />
                </PrivateRoute>
              }
            />
            <Route path="/support" element={<Support />} />
          </Routes>
        </div>
        <Footer />
      </div>
    </Router>
  );
}

export default App;