import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { register } from './userService';
import './Register.css';

const Register = () => {
  const [email, setEmail] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [gender, setGender] = useState('');
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();
  const [usernameAvailable, setUsernameAvailable] = useState(true);

  const validateEmail = (value) => {
    if (!value.includes('@')) {
      return 'Email is missing "@"';
    }else if(value.trim() === ''){

    }
    return '';
  };

  const validatePhoneNumber = (value) => {
    if (!/^\d+$/.test(value)) {
      return 'Phone number must contain only digits';
    }
    else if (value.length < 10) {
      return 'Phone number must be at least 10 digits';
    }else{
        return '';
    }
    
  };

  const validatePassword = (value) => {
    const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$/;
    if (!passwordRegex.test(value)) {
      return 'Password must be at least 6 characters with one uppercase letter, one numeric digit, and one special character';
    }else{
        return '';
    }
  };

  const validateConfirmPassword = (value) => {
    if (value !== password) {
      return 'Passwords do not match';
    }else if(value.trim() === ''){
        return 'please confirm password';
    }else{
        return '';
    }
  };
  const validateFirstName = (value) => {
    if (value.trim() === '') {
      return 'First name cannot be empty';
    }
    return '';
  };
  const validateUsername = async (value) => {
    if (value.trim() === '') {
      return 'Username cannot be empty';
    }
    try {
      const response = await fetch(`http://localhost:3004/users?username=${value}`);
      const data = await response.json();
      if (data.length > 0) {
        setUsernameAvailable(false);
        return 'Username already taken';
      } else {
        setUsernameAvailable(true);
        return '';
      }
    } catch (error) {
      console.error('Error checking username availability:', error);
      return 'Error checking username availability';
    }
  };

  const handleValidation = (field, value) => {
    let error = '';
    switch (field) {
      case 'email':
        error = validateEmail(value);
        break;
      case 'phoneNumber':
        error = validatePhoneNumber(value);
        break;
      case 'password':
        error = validatePassword(value);
        break;
      case 'confirmPassword':
        error = validateConfirmPassword(value);
        break;
      case 'firstName':
        error = validateFirstName(value);
        break;
      case 'username':
        error = validateUsername(value);
        break;
        
      default:
        break;
    }
    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: error,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = Object.values(errors).every((error) => error === '');
    if (isValid) {
      try {
        const user = await register({
          email,
          phoneNumber,
          firstName,
          lastName,
          username,
          password,
          dateOfBirth,
          gender,
        });
        if (user) {
          navigate('/login');
        } else {
          setErrors({ submit: 'An error occurred while registering. Please try again.' });
        }
      } catch (err) {
        setErrors({ submit: 'An error occurred while registering. Please try again.' });
      }
    }
  };
  const handleAlreadyuser = ()=> {
    navigate('/Login');
  }


  return (
    <div className='register'>
      <h2>Create a Broadgram Account</h2>
      {errors.submit && <p style={{ color: 'red' }}>{errors.submit}</p>}
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
              handleValidation('email', e.target.value);
            }}
          />
          {errors.email && <p style={{ color: 'red' }}>{errors.email}</p>}
        </div>
        <div>
          <label htmlFor="phoneNumber">Phone Number</label>
          <input
            type="tel"
            id="phoneNumber"
            value={phoneNumber}
            onChange={(e) => {
              setPhoneNumber(e.target.value);
              handleValidation('phoneNumber', e.target.value);
            }}
          />
          {errors.phoneNumber && <p style={{ color: 'red' }}>{errors.phoneNumber}</p>}
        </div>
        <div>
          <label htmlFor="firstName">First Name</label>
          <input
            type="text"
            id="firstName"
            value={firstName}
            onChange={(e) => {
              setFirstName(e.target.value);
              handleValidation('firstName', e.target.value);
            }}
          />
          {errors.firstName && <p style={{ color: 'red' }}>{errors.firstName}</p>}
        </div>
        <div>
          <label htmlFor="lastName">Last Name</label>
          <input
            type="text"
            id="lastName"
            value={lastName}
            onChange={(e) => {
              setLastName(e.target.value);
              handleValidation('lastName', e.target.value);
            }}
          />
        </div>
        <div>
          <label htmlFor="username">Username</label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={async (e) => {
              setUsername(e.target.value);
              const error = await validateUsername(e.target.value);
              setErrors((prevErrors) => ({
                ...prevErrors,
                username: error,
              }));
            }}
          />
          {errors.username && <p style={{ color: 'red' }}>{errors.username}</p>}
        </div>
        <div>
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
              handleValidation('password', e.target.value);
            }}
          />
          {errors.password && <p style={{ color: 'red' }}>{errors.password}</p>}
        </div>
        <div>
          <label htmlFor="confirmPassword">Confirm Password</label>
          <input
            type="password"
            id="confirmPassword"
            value={confirmPassword}
            onChange={(e) => {
              setConfirmPassword(e.target.value);
              handleValidation('confirmPassword', e.target.value);
            }}
          />
          {errors.confirmPassword && <p style={{ color: 'red' }}>{errors.confirmPassword}</p>}
        </div>
        <div>
          <label htmlFor="dateOfBirth">Date of Birth</label>
          <input
            type="date"
            id="dateOfBirth"
            value={dateOfBirth}
            onChange={(e) => setDateOfBirth(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor="gender">Gender</label>
          <select
            id="gender"
            value={gender}
            onChange={(e) => setGender(e.target.value)}>
            <option value="">Select Gender</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
          </select>
        </div>
        <button type="submit">Register</button>
        <button type='button' onClick={handleAlreadyuser}>Already a User! Login here</button>
      </form>
    </div>
  );
};

export default Register;
